package com.javalec.ex.BCommand;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.javalec.ex.BDao.BDao;
import com.javalec.ex.BDto.BDto;

public class BContentViewcommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		int bId=Integer.parseInt(request.getParameter("bId")) ;
		int rnum=Integer.parseInt(request.getParameter("rnum")) ;
		int page=Integer.parseInt(request.getParameter("page"));
		ArrayList<BDto> list=new ArrayList<BDto>();
		BDao dao = new BDao();
		list = dao.content_view(bId,rnum);
		int size =list.size();
		System.out.println(size);
		request.setAttribute("content_view", list);
		request.setAttribute("size", size);
		request.setAttribute("rnum", rnum);
		request.setAttribute("page", page);
	}

}
