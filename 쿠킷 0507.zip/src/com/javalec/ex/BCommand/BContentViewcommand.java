package com.javalec.ex.BCommand;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.javalec.ex.BDao.BDao;
import com.javalec.ex.BDto.BDto;

public class BContentViewcommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		int bId=Integer.parseInt(request.getParameter("bId")) ;
		System.out.println(bId);
		int page=Integer.parseInt(request.getParameter("page"));
		ArrayList<BDto> list=new ArrayList<BDto>();
		
		BDao dao = new BDao();
		list = dao.content_view(bId);
		System.out.println("list사이즈:"+list.size());
		request.setAttribute("content_view", list);
		request.setAttribute("page", page);
	}

}
