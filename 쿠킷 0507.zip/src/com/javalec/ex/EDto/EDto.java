package com.javalec.ex.EDto;

import java.sql.Date;

public class EDto {
 
	public EDto() {
		
	}
	
	public EDto(int eId, int eFlag, String eTitle, String eTitleimg, String eContentimg, String eDate) {
		this.eId = eId;
		this.eFlag = eFlag;
		this.eTitle = eTitle;
		this.eTitleimg = eTitleimg;
		this.eContentimg = eContentimg;
		this.eDate = eDate;
	}

	int eId,eFlag;
	String eTitle,eTitleimg,eContentimg,eDate;
	
	
	public int geteId() {
		return eId;
	}
	public void seteId(int eId) {
		this.eId = eId;
	}
	public int geteFlag() {
		return eFlag;
	}
	public void seteFlag(int eFlag) {
		this.eFlag = eFlag;
	}
	public String geteTitle() {
		return eTitle;
	}
	public void seteTitle(String eTitle) {
		this.eTitle = eTitle;
	}
	public String geteTitleimg() {
		return eTitleimg;
	}
	public void seteTitleimg(String eTitleimg) {
		this.eTitleimg = eTitleimg;
	}
	public String geteContentimg() {
		return eContentimg;
	}
	public void seteContentimg(String eContentimg) {
		this.eContentimg = eContentimg;
	}
	public String geteDate() {
		return eDate;
	}
	public void seteDate(String eDate) {
		this.eDate = eDate;
	}
	
	
	
	
	
	
	
}
