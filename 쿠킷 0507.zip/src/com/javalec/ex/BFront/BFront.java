package com.javalec.ex.BFront;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.javalec.ex.BCommand.*;

@WebServlet("*.do")
public class BFront extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public BFront() {
    	
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionDo(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionDo(request, response);
	}
	
	protected void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException{
		
		request.setCharacterEncoding("utf-8");
		String pageView=null;
		BCommand bcom=null;
		String uri=request.getRequestURI();
		String conPath=request.getContextPath();
		String com=uri.substring(conPath.length());
		

		//공지사항 관련(회원)
		
		
		if(com.equals("/list.do")) {
			bcom=new BListcommand();
			bcom.execute(request, response);
			pageView = "list.jsp";
		}
		else if(com.equals("/content_view.do")) {
			bcom=new BContentViewcommand();
			bcom.execute(request, response);
			pageView="content_view.jsp";
		}
		
		else if(com.equals("/search.do")) {
			bcom=new BSearchcommand();
			bcom.execute(request, response);
			pageView="list.jsp";
		}
		
		
		//이벤트 페이지 관련(회원)
		
		
		else if(com.equals("/elist.do")) {
			bcom=new EListcommand();
			bcom.execute(request, response);
			pageView="event_list.jsp";
		}
		else if(com.equals("/econtent_view.do")) {
			bcom=new EContentViewcommand();
			bcom.execute(request, response);
			pageView="econtent_view.jsp";
		}
		
		//리뷰관련(회원)
		
		else if(com.equals("/rlist.do")) {
			bcom=new RListcommand();
			bcom.execute(request, response);
			pageView="rlist.jsp";
		}
		
		//상품관련(회원)
		
		else if(com.equals("/plist.do")) {
			bcom=new PListcommand();
			bcom.execute(request, response);
			pageView="plist.jsp";
		}
		else if(com.equals("/pcontent_view.do")) {
			bcom=new PContentViewcommand();
			bcom.execute(request, response);
			pageView="pcontent_view.jsp";
		}
		
		
		//회원관련(로그인,회원가입)
		
		
		else if(com.equals("/login.do")) {
			bcom=new BLogincommand();
			bcom.execute(request, response);
			pageView="index.jsp";
		}
		else if(com.equals("/idcheck.do")) {
			bcom=new MIdcheckcommand();
			bcom.execute(request, response);
			pageView="join_idcheck.jsp";
		}
		else if(com.equals("/join.do")) {
			bcom=new MJoincommand();
			bcom.execute(request, response);
			pageView="login.jsp";
		}
		else if(com.equals("/mmodify_view.do")) {
			bcom=new MModifyViewcommand();
			bcom.execute(request, response);
			pageView="mmodify_view.jsp";
		}
		else if(com.equals("/mmodify.do")) {
			bcom=new MModifycommand();
			bcom.execute(request, response);
			pageView="index.jsp";
		}
		
		//admin로그인
		
		
		else if(com.equals("/admin_login.do")) {
			bcom=new ALogincommand();
			bcom.execute(request, response);
			pageView="admin_main.jsp";
		}
		
		//admin이벤트관리
		
		
		else if(com.equals("/admin_elist.do")) {
			bcom=new EListcommand();
			bcom.execute(request, response);
			pageView="admin_event_list.jsp";
		}
		else if(com.equals("/admin_econtent_view.do")) {
			bcom=new EContentViewcommand();
			bcom.execute(request, response);
			pageView="admin_econtent_view.jsp";
		}
		else if(com.equals("/ewrite.do")) {
			bcom=new EWritecommand();
			bcom.execute(request, response);
			pageView="admin_elist.do";
		}
		else if(com.equals("/edelete.do")) {
			bcom=new EDeletecommand();
			bcom.execute(request, response);
			pageView="admin_elist.do";
		}
		else if(com.equals("/emodify_view.do")) {
			bcom=new EContentViewcommand2();
			bcom.execute(request, response);
			pageView="admin_emodify_view.jsp";
		}
		else if(com.equals("/emodify.do")) {
			bcom=new EModifycommand();
			bcom.execute(request, response);
			pageView="admin_econtent_view.jsp";
		}
		
		
		//admin 공지사항 관리
		
		
		else if(com.equals("/admin_list.do")) {
			bcom=new BListcommand();
			bcom.execute(request, response);
			pageView = "admin_list.jsp";
		}
		else if(com.equals("/admin_content_view.do")) {
			bcom=new BContentViewcommand();
			bcom.execute(request, response);
			pageView="admin_content_view.jsp";

		}
		else if(com.equals("/admin_search.do")) {
			bcom=new BSearchcommand();
			bcom.execute(request, response);
			pageView="admin_list.jsp";
		}
		else if(com.equals("/write.do")) {
			bcom=new BWritecommand();
			bcom.execute(request, response);
			pageView="admin_list.do";
		}
		else if(com.equals("/delete.do")) {
			bcom=new BDeletecommand();
			bcom.execute(request, response);
			pageView="admin_list.do";
		}
		else if(com.equals("/modify_view.do")) {
			bcom=new BContentViewcommand2();
			bcom.execute(request, response);
			pageView="modify_view.jsp";
		}
		else if(com.equals("/modify.do")) {
			bcom=new BModifycommand();
			bcom.execute(request, response);
			pageView="admin_content_view.jsp";
		}
		else if(com.equals("/reply_view.do")) {
			bcom=new BContentViewcommand2();
			bcom.execute(request, response);
			pageView="reply_view.jsp";
		}
		else if(com.equals("/reply.do")) {
			bcom=new BReplycommand();
			bcom.execute(request, response);
			pageView="admin_list.do";
		}
		
		//admin 상품관리
		
		else if(com.equals("/admin_plist.do")) {
			bcom=new PListcommand();
			bcom.execute(request, response);
			pageView="admin_plist.jsp";
		}
		
		else if(com.equals("/pwrite.do")) {
			bcom=new PWritecommand();
			bcom.execute(request, response);
			pageView="admin_plist.do";
		}
		
		
		
		
		
		
		RequestDispatcher dispatcher=request.getRequestDispatcher(pageView);
		dispatcher.forward(request, response);
		
		
	}

}
