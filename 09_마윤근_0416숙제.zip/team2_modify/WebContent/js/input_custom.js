
$(document).ready(function(){
	
	//글자수 카운트
    $('#txt_wr').keyup(function(e){
    	var leng = $(this).val().length;
    	$('.counter').text(leng);
    });
    
    
    
    
    
    
});

