package com.javalec.ex.MDao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.javalec.ex.BDto.BDto;
import com.javalec.ex.MDto.MDto;

public class MDao {

	//db연결 필요 변수
			Context context=null;
			DataSource ds=null;
			Connection con=null;
			PreparedStatement pstmt=null;
			ResultSet rs=null;
			String sql=null;
			
			
			ArrayList<MDto> list=new ArrayList<MDto>();
			MDto dto=new MDto();
			
			//데이터를 받는데 필요변수
			String id,pw,name,email_head,email_tail,address,phone_head,phone_mid,phone_tail,news,sms;
			Date birth;
			Timestamp j_date,u_date;
			
			
			//생성자
			public MDao() {
				//커넥션풀 생성(생성하자마자)
				try {
					context=new InitialContext();
					ds=(DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
			
			//회원로그인
			public int login(String id,String pw,HttpSession session) {
				
				int check=0;
				sql="select id,pw,name from lms_member2 where id=? and pw=?";
				try {
					con=ds.getConnection();
					pstmt=con.prepareStatement(sql);
					pstmt.setString(1, id);
					pstmt.setString(2, pw);
					rs=pstmt.executeQuery();
					if(rs.next()) {
						check=1;
						session.setAttribute("id",id);
						session.setAttribute("pw", rs.getString("pw"));
						session.setAttribute("name", rs.getString("name"));
					}
				}catch(Exception e) {
					e.printStackTrace();
				}
				finally {
					try {
						if(rs!=null) rs.close();
						if(pstmt!=null) pstmt.close();
						if(con!=null) con.close();
					}catch(Exception e2) {
						e2.printStackTrace();
					}
				}
				
				return check;
				
			}//login
	
	
	
}//class
