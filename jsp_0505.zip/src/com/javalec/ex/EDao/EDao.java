package com.javalec.ex.EDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.javalec.ex.EDto.EDto;

public class EDao {
			//db연결 필요 변수
			Context context=null;
			DataSource ds=null;
			Connection con=null;
			PreparedStatement pstmt=null;
			ResultSet rs=null;
			String sql=null;
			
			
			ArrayList<EDto> list=new ArrayList<EDto>();
			EDto dto=new EDto();
			
			//데이터를 받는데 필요변수
			int eId,eFlag;
			String eTitle,eTitleimg,eContentimg,eDate;
			
			
			//생성자
			public EDao() {
				//커넥션풀 생성(생성하자마자)
				try {
					context=new InitialContext();
					ds=(DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
			
			
			//전체 select-list
			public ArrayList<EDto> elist(int page,int limit) {
				//번호를 붙여서 가져옴(최대 갯수만큼)
				int startrow=(page-1)*10+1;
				int endrow=startrow+limit-1;
				
				sql="select * from (select rownum rnum,eId,eTitle,eTitleimg,eContentimg,eDate from"+ 
					"(select * from mvc_event order by eId asc)) where rnum>=? and rnum<=?";
				
				try {
					con=ds.getConnection();
					pstmt=con.prepareStatement(sql);
					pstmt.setInt(1, startrow);
					pstmt.setInt(2, endrow);
					rs=pstmt.executeQuery();
					while(rs.next()) {
						eId=rs.getInt("eId");
						eTitle=rs.getString("eTitle");
						eTitleimg=rs.getString("eTitleimg");
						eContentimg=rs.getString("eContentimg");
						eDate=rs.getString("eDate");
						dto=new EDto(eId, 0, eTitle, eTitleimg, eContentimg, eDate);
						list.add(dto);
					}
				}catch(Exception e) {
					e.printStackTrace();
				}
				finally {
					try {
						if(rs!=null) rs.close();
						if(pstmt!=null) pstmt.close();
						if(con!=null) con.close();
					}catch(Exception e2) {
						e2.printStackTrace();
					}
				}
				
				return list;
				
			}//전체 select
			
			//이벤트 추가(insert)
			public int ewrite(String eTitle,String eDate,String name1,String name2) {
				sql="insert into mvc_event values(mvc_event_seq.nextval,?,?,?,?,sysdate)";
				int check=0;
				try {
					con=ds.getConnection();
					pstmt=con.prepareStatement(sql);
					pstmt.setString(1, eTitle);
					pstmt.setString(2, name1);
					pstmt.setString(3, name2);
					pstmt.setString(4, eDate);
					check=pstmt.executeUpdate();
				}catch(Exception e) {
					e.printStackTrace();
				}
				finally {
					try {
						if(pstmt!=null) pstmt.close();
						if(con!=null) con.close();
					}catch(Exception e2) {
						e2.printStackTrace();
					}
				}
				return check;
			}//이벤트 입력(insert)
			
			//전체 카운트 얻어오기
			public int getelistCount() {
				
				int count=0;
				
				sql="select count(*) as count from mvc_event";
				
				try {
					con=ds.getConnection();
					pstmt=con.prepareStatement(sql);
					rs=pstmt.executeQuery();
					if(rs.next()) {
						count=rs.getInt("count");
					}
					
				}catch(Exception e) {
					e.printStackTrace();
				}
				finally {
					try {
						if(rs!=null) rs.close();
						if(pstmt!=null) pstmt.close();
						if(con!=null) con.close();
					}catch(Exception e2) {
						e2.printStackTrace();
					}
				}
				
				return count;
			}//전체 카운트 얻어오기
}
